//승인버튼
  function goToApproval(brNum) {
        window.location.href = "/adminRegistration/approvalBusinessRegistration.do?brNum="+brNum;
    }