//상세정보로이동
function goToDetailPage(url) {
  window.location.href = url;
}

